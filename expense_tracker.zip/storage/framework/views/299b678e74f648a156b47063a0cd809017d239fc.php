
<nav class="navbar navbar-expand-sm bg-dark navbar-dark sticky-top">
    <div class="container-fluid">
      <h1 class=" navbar-brand text-white">Welcome <?php echo e($data->username); ?></h1>
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link" id="login" href="logout">Logout</a>
          </li>
        </ul>
    </div>
  </nav>
<?php echo $__env->make('user.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u992071199/domains/cam2netict.net/public_html/Expense_Tracker/resources/views/user/navbar.blade.php ENDPATH**/ ?>