

<?php $__env->startSection('content'); ?>

<div class="containier-fluid p-5">
    <div class="row justify-content-md-center">
        <div class="col-sm-5 col-sm-offset-4">
            <h1 class="text-center text-primary">Welcome <?php echo e($data->username); ?></h1>
            <a class="text-primary" href="logout">Logout</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp1\htdocs\expense_tracker\resources\views/dashboard.blade.php ENDPATH**/ ?>