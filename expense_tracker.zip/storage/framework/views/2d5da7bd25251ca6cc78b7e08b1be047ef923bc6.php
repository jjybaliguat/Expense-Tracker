<footer>
    <div class="row p-2 bg-primary">
        <p class="text-center text-white">
                All Rights Reserved! &copy;2022 Justine Jerald Baliguat
        </p>
    </div>
</footer><?php /**PATH D:\xampp1\htdocs\expense_tracker\resources\views/user/footer.blade.php ENDPATH**/ ?>