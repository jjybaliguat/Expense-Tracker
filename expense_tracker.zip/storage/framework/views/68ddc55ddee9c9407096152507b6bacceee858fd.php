<footer>
    <div class="row p-2 bg-primary">
        <p class="text-center text-white">
                All Rights Reserved! &copy;2022 Justine Jerald Baliguat
        </p>
    </div>
</footer><?php /**PATH /home/u992071199/domains/cam2netict.net/public_html/Expense_Tracker/resources/views/user/footerDashboard.blade.php ENDPATH**/ ?>