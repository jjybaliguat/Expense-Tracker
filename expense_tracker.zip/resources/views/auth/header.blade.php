<nav class="navbar navbar-expand-sm bg-dark navbar-dark">
  <div class="container-fluid d-flex justify-content-center">
    <h1 class="text-white">Welcome To Expense Tracker</h1>
      <!--<ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" id="login" href="login">Login</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" id="register" href="register">Sign-up</a>
        </li>
      </ul>-->
  </div>
</nav>